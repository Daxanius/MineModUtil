Template Information

Templates are made by the user of the program.
This means you have to create your templates yourself.

Don't worry, it's not hard!

All you do is make a .txt file where the name starts with template_
For example template_banana.txt

You can write whatever code or whatever shit in there, because essentially all
the program looks for are the placeholders you put in there.

The placeholders you can put in there are:

- {folder:sub} : The modname and subfolder (for example lootplusplus:items)
- {directory} : The selected directory of the outputed .JSON file.
- {item_name} : The chosen name of the file.
- {item_type} : The selected type of item.